import '/flutter_flow/flutter_flow_util.dart';
import 'home_card_widget.dart' show HomeCardWidget;
import 'package:flutter/material.dart';

class HomeCardModel extends FlutterFlowModel<HomeCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
